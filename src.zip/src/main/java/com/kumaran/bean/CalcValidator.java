package com.kumaran.bean;

public class CalcValidator {

}
	